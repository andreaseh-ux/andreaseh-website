ANDREAS HOLST — PORTFOLIO DEMO

1. Åpne index.html i en nettleser for å se siden.
2. Bytt ut bildene i index.html med egne bilder/videoer.
3. Endre hello@andreaseholst.no til riktig e-postadresse.
4. Last opp mappen til en host som Vercel eller Netlify og koble eventuelt eget domene.

Designet er laget som en mørk, cinematic portfolio-side for FPV-drone, reise og samarbeid.
